
 
package data.structures.project;

import java.io.IOException;

public class DTS   {
public static void main(String[] args) throws IOException {
    Points smsGame = new Points();
		
		smsGame.readFromFile("file.txt"); 
		
		smsGame.points(); 

            
        
}
}
