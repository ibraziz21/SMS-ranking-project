
package data.structures.project;

import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
		
public class Points{
	
	private static final String[] PRIZES = {"iPhone X","Samsung 6 edge","KES 10,000",
			"KES 1,000 Meal Voucher","KES 1,000 Meal Voucher"};
	
	private static people[] person = new people[5];
	private static int count = 0;	
	
	
	public void readFromFile(String fileName) {
				 System.out.println("Reading from the file " + "\"" + fileName + "\"");
				 Scanner inputStream = null;
				 Scanner lineByLine = null;
				 try{
					 inputStream = new Scanner(new FileInputStream(fileName));
					 }catch (FileNotFoundException e){
						 System.out.println("File.txt was not found");
						 System.out.println("or could not be opened.");
						 System.exit(0);
					 }
				 
				 inputStream.nextLine(); 
				 inputStream.nextLine();
				 inputStream.nextLine(); 
				 inputStream.nextLine(); 
				 
				 try{
					 
					 for(count = 0; count < 5; count++) {

						 lineByLine = new Scanner(inputStream.nextLine());
						 lineByLine.useDelimiter("/");
						 person[count] = new people(lineByLine.next().trim(), lineByLine.next().trim(), 
								 lineByLine.next().trim(), lineByLine.next().trim(), 
								 Integer.parseInt(lineByLine.next().trim().substring(0,1)),
								 Integer.parseInt(lineByLine.next().trim().substring(0,1)), 
								 Integer.parseInt(lineByLine.next().trim().substring(0,1)));
						 
					 }
				 
				 inputStream.close( );
				 lineByLine.close( );

				 }catch (Exception e){
					 System.out.println("Error reading file, ");
					 System.out.println("modify layout of columns.");
					 System.exit(0);
				 }
				  
				 } 
	
		

		public void points() {
			for(count = 0; count < 5; count++) {
				if(person[count].getQuestionOne().equals("Correct")) {
					person[count].setPoints(person[count].getPoints() + 5);
				}
				if(person[count].getQuestionTwo().equals("Correct")) {
					person[count].setPoints(person[count].getPoints() + 5);
				}
				if(person[count].getQuestionThree().equals("Correct")) {
					person[count].setPoints(person[count].getPoints() + 5);
				}
			}
			bonus(); 
			
			insertionSorter(); 
			
			displayPointsAndPrizes(); 
		}
		
		public void bonus() {
			int questionNumber = 1;

			while(true) {
			switch(questionNumber) {
			case 1:
			boolean giveBonusPoints = true;
				for(count = 0; count < 5 ; count++) {
				if(person[count].getQuestionOneResponse() == 1) {
					if(person[count].getQuestionOne().equals("Correct")) {
						person[count].setPoints(person[count].getPoints() + 3);
					}else {
						
						giveBonusPoints = false;
					}
				  }
				}
				
				for(count = 0; count < 5 ; count++) {
				if((person[count].getQuestionOneResponse() == 2) &&
						person[count].getQuestionOne().equals("Correct") && giveBonusPoints) {
					person[count].setPoints(person[count].getPoints() + 2);
					}
				}
					
				for(count = 0; count < 5 ; count++) {
				if((person[count].getQuestionOneResponse() == 3) && 
						person[count].getQuestionOne().equals("Correct") && giveBonusPoints) {
					person[count].setPoints(person[count].getPoints() + 1);
				  }
			   }
				questionNumber++;
				break;
			case 2:
				giveBonusPoints = true;
				for(count = 0; count < 5 ; count++) {
				if(person[count].getQuestionTwoResponse() == 1) {
					if(person[count].getQuestionTwo().equals("Correct")) {
						person[count].setPoints(person[count].getPoints() + 3);
					}else {
						
						giveBonusPoints = false;
					}
				  }
				}
				
				for(count = 0; count < 5 ; count++) {
				if((person[count].getQuestionTwoResponse() == 2) &&
						person[count].getQuestionTwo().equals("Correct") && giveBonusPoints) {
					person[count].setPoints(person[count].getPoints() + 2);
					}
				}
					
				for(count = 0; count < 5 ; count++) {
				if((person[count].getQuestionTwoResponse() == 3) && 
						person[count].getQuestionTwo().equals("Correct") && giveBonusPoints) {
					person[count].setPoints(person[count].getPoints() + 1);
				  }
			   }
				questionNumber++;
				break;
			case 3:
				giveBonusPoints = true;
				for(count = 0; count < 5 ; count++) {
				if(person[count].getQuestionThreeResponse() == 1) {
					if(person[count].getQuestionThree().equals("Correct")) {
						person[count].setPoints(person[count].getPoints() + 3);
					}else {
						
						giveBonusPoints = false;
					}
				  }
				}
				
				for(count = 0; count < 5 ; count++) {
				if((person[count].getQuestionThreeResponse() == 2) &&
						person[count].getQuestionThree().equals("Correct") && giveBonusPoints) {
					person[count].setPoints(person[count].getPoints() + 2);
					}
				}
					
				for(count = 0; count < 5 ; count++) {
				if((person[count].getQuestionThreeResponse() == 3) && 
						person[count].getQuestionThree().equals("Correct") && giveBonusPoints) {
					person[count].setPoints(person[count].getPoints() + 1);
				  }
			   }
				break;
			}
			if (questionNumber == 3) {
				break;
			}
		}
	   }
		
		public void displayPointsAndPrizes() {
			System.out.println("Points And Prizes : ");
			for(count = 0; count < 5; count++) {
				System.out.println( person[count].getName() + 
						 "\t" + person[count].getPoints() + 
						" points,\t " + "Gets "+PRIZES[count]+"\n");
			}
		}
		
		public void insertionSorter() { 
			
			int i;
			int j;
			int key;
			
			String storeName;
			String storeQuestionOne;
			String storeQuestionTwo;
			String storeQuestionThree;
			int storeQuestionOneResponse;
			int storeQuestionTwoResponse;
			int storeQuestionThreeResponse;
			
			for(i = 1; i < person.length; ++i) {
				key = person[i].getPoints();
				
				storeName = person[i].getName();
				storeQuestionOne = person[i].getQuestionOne();
				storeQuestionTwo = person[i].getQuestionTwo();
				storeQuestionThree = person[i].getQuestionThree();
				storeQuestionOneResponse = person[i].getQuestionOneResponse();
				storeQuestionTwoResponse = person[i].getQuestionTwoResponse();
				storeQuestionThreeResponse = person[i].getQuestionThreeResponse();
				
				j = i - 1;
				
				while (j>=0 && person[j].getPoints() < key) {
					person[j + 1].setPoints(person[j].getPoints());
					
					person[j + 1].setName(person[j].getName());
					person[j + 1].setQuestionOne(person[j].getQuestionOne());
					person[j + 1].setQuestionTwo(person[j].getQuestionTwo());
					person[j + 1].setQuestionThree(person[j].getQuestionThree());
					person[j + 1].setQuestionOneResponse(person[j].getQuestionOneResponse());
					person[j + 1].setQuestionTwoResponse(person[j].getQuestionTwoResponse());
					person[j + 1].setQuestionThreeResponse(person[j].getQuestionThreeResponse());
					j = j - 1;
				}
				person[j + 1].setPoints(key);
				
				person[j + 1].setName(storeName);
				person[j + 1].setQuestionOne(storeQuestionOne);
				person[j + 1].setQuestionTwo(storeQuestionTwo);
				person[j + 1].setQuestionThree(storeQuestionThree);
				person[j + 1].setQuestionOneResponse(storeQuestionOneResponse);
				person[j + 1].setQuestionTwoResponse(storeQuestionTwoResponse);
				person[j + 1].setQuestionThreeResponse(storeQuestionThreeResponse);

			  }
			System.out.println("");
		   }
}
