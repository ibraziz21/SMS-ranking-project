/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data.structures.project;

/**
 *
 * @author ibraziz21
 */
public class people{
	
		private String name;
		private String questionOne;
		private String questionTwo;
		private String questionThree;
		private int questionOneResponse;
		private int questionTwoResponse;
		private int questionThreeResponse;
		private int points;
		
		
		public people() {
			 name = "";
			 questionOne = "";	
			 questionTwo = "";		 
			 questionThree = "";	
			 questionOneResponse = 0;
			 questionTwoResponse = 0;	
			 questionThreeResponse = 0;
			 points = 0;
		}
		
		public people(String name,String questionOne,String questionTwo,
				String questionThree,int questionOneResponse,int questionTwoResponse,
				int questionThreeResponse) {
			 this.name = name;
			 this.questionOne = questionOne;	
			 this.questionTwo = questionTwo;		 
			 this.questionThree = questionThree;	
			 this.questionOneResponse = questionOneResponse;
			 this.questionTwoResponse = questionTwoResponse;	
			 this.questionThreeResponse = questionThreeResponse;
			 this.points = 0;
		}
		
		
		public String getName() {
			return name;
		}
		public String getQuestionOne() {
			return questionOne;
		}
		public String getQuestionTwo() {
			return questionTwo;
		}
		public String getQuestionThree() {
			return questionThree;
		}
		public int getQuestionOneResponse() {
			return questionOneResponse;
		}
		public int getQuestionTwoResponse() {
			return questionTwoResponse;
		}
		public int getQuestionThreeResponse() {
			return questionThreeResponse;
		}
		public int getPoints() {
			return points;
		}
		
		
		public void setName(String name) {
			this.name = name;
		}
		public void setQuestionOne(String questionOne) {
			this.questionOne = questionOne;
		}
		public void setQuestionTwo(String questionTwo) {
			this.questionTwo = questionTwo;
		}
		public void setQuestionThree(String questionThree) {
			this.questionThree = questionThree;
		}
		public void setQuestionOneResponse(int questionOneResponse) {
			this.questionOneResponse = questionOneResponse;
		}
		public void setQuestionTwoResponse(int questionTwoResponse) {
			this.questionTwoResponse = questionTwoResponse;
		}
		public void setQuestionThreeResponse(int questionThreeResponse) {
			this.questionThreeResponse = questionThreeResponse;
		}
		public void setPoints(int points) {
			this.points = points;
		}
		
				public String toString() {
			return ("" + name + 
					", " + questionOne + ",  " + questionTwo + 
					",  " + questionThree + ",  " + questionOneResponse + 
					",  " + questionTwoResponse + ",  " + questionThreeResponse);
		}
	}